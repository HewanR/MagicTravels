export enum ActionType {
    updateIsUserLoggedIn,
    connectToSocket
}