
export class AppState {
    public isUserLoggedIn: boolean = false;
    public socket: any;
}