export class UserLoginDetails {
    public constructor(
        public userName?: string,
        public password?: string
    ) { }

}
