export class UserRegisterDetails {
    public constructor(
        public firstName?: string,
        public lastName?: string,
        public userName?: string,
        public password?: string
    ) { }

}
