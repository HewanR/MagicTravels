A Pen created at CodePen.io. You can find this one at http://codepen.io/robeen/pen/PbvJjy.

 The Twitter [Like button] made only using SVG and CSS3 animations.