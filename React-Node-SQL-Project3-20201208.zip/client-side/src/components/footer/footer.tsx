import React from "react";

import './footer.css';

export default function Footer() {
    return (
        <div className="footer">
           (C) All rights reserved to Hewan Rada 
        </div>
    )
}