const usersList = [
    {userId:0, firstName: "Moshe", lastName: "Oofnik", userName: "Moof", password: "766342084f4872910acc23a16dcf14c1", userType: "Admin"},
    {userId:1, firstName: "Oogi", lastName: "Fletzet", userName: "Oogf", password: "766342084f4872910acc23a16dcf14c1", userType: "Customer"}
];

module.exports = usersList;