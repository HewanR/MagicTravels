let socketIOCache = new Map()

module.exports = socketIOCache;